import { FaFacebook } from "react-icons/fa";
const Facebookcom = () => {
    return (
        <>
            <FaFacebook style={{marginTop:'20px',marginRight:'10px'}}/>
        </>
    )
}
export default Facebookcom;

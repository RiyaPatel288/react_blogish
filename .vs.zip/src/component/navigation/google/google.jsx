import { FaGoogle } from "react-icons/fa";
const Googlecom = () => {
    return (
        <>
            <FaGoogle style={{marginTop:'20px',marginRight:'10px'}}/>
        </>
    )
}
export default Googlecom;
